Corduba
-------
A python based provisioning server for the DeepSeneca App. 

Prerequisites
-------------
- Python
### uvicorn
Uvicorn is an asynchronous web server implementation based on the ASGI (Asynchronous Server Gateway Interface) standard. It is designed to serve ASGI applications, which are a modern replacement for the older WSGI standard. This is used to run FastAPI apps, which Corduba is based on.

Installation
------------




Running corduba
---------------
### Windows

Corduba uses fastapi for 


### Ubuntu

Daily tasks file
----------------
- Purpose
- Structure

